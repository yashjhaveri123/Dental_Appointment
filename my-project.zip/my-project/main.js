import Vapi from "@vapi-ai/web";

const publicKey = "e4eed68b-93f2-41cc-ad6f-82694e609077";
const assistantId = "a597e40e-8cb7-494d-ac38-f7e769d1fe67";

const chatLogs = document.getElementById("chat-logs");
const bookingLogs = document.getElementById("booking-logs");
const voiceButton = document.getElementById("voice-button");
const hangUpButton = document.getElementById("hang-up-button");

let vapiInstance = null;
let bookingDetails = ""; // Temporary storage for appointment data

// Function to append messages to the chat logs
const appendChatLog = (message, isError = false) => {
    const log = document.createElement("div");
    log.style.padding = "0.5rem";
    log.style.color = isError ? "red" : "#333";
    log.textContent = message;
    chatLogs.appendChild(log);
};

// Function to append a styled booking box to the bookings section
const appendBookingBox = (details) => {
    const bookingBox = document.createElement("div");
    bookingBox.classList.add("booking-box");
    bookingBox.textContent = details;
    bookingLogs.appendChild(bookingBox);
};

// Function to extract booking details from assistant's message
const extractBookingDetails = (content) => {
    const dateMatch = content.match(/(\d{1,2}(st|nd|rd|th)\s\w+)/i);
    const timeMatch = content.match(/(\d{1,2}:\d{2}\s*(am|pm))/i);
    const procedureMatch = content.match(/(root canal|cleaning|check-up|filling)/i);
    const nameMatch = content.match(/booked for (\w+)/i);

    const date = dateMatch ? dateMatch[0] : "Unknown Date";
    const time = timeMatch ? timeMatch[0] : "Unknown Time";
    const procedure = procedureMatch ? procedureMatch[0] : "Unknown Procedure";
    const name = nameMatch ? nameMatch[1] : "Unknown Name";

    const extractedDetails = `📅 ${date} at ${time} - ${procedure} for ${name}`;
    console.log("Extracted Booking Details:", extractedDetails); // Log extracted details
    return extractedDetails;
};


// Start the Vapi voice bot
const startVoiceBot = async () => {
    if (vapiInstance) {
        appendChatLog("Voice bot is already running!");
        return;
    }

    appendChatLog("Activating Voice Bot...");

    try {
        vapiInstance = new Vapi(publicKey);
        const call = await vapiInstance.start(assistantId);

        // Event: Call starts
        call.onStart = () => appendChatLog("Call Started.");

        // Event: Assistant sends a message
        call.onMessage = (msg) => {
            appendChatLog(`Assistant: ${msg.content}`);
            if (msg.content.toLowerCase().includes("appointment booked")) {
                bookingDetails = extractBookingDetails(msg.content);
                appendChatLog("Appointment details captured.");
            }
        };

        // Event: Call ends
        call.onEnd = () => {
            appendChatLog("Call Ended.");
            if (bookingDetails) {
                appendBookingBox(bookingDetails);
            }
            vapiInstance = null;
        };
    } catch (error) {
        appendChatLog(`Error: ${error.message}`, true);
        console.error(error);
        vapiInstance = null;
    }
};

// Function to manually hang up the call
const hangUpCall = () => {
    if (vapiInstance) {
        vapiInstance.stop();
        appendChatLog("Call manually ended.");
        if (bookingDetails) {
            appendBookingBox(bookingDetails);
        }
        vapiInstance = null;
    } else {
        appendChatLog("No active call to hang up.");
    }
};

// Add event listeners
voiceButton.addEventListener("click", startVoiceBot);
hangUpButton.addEventListener("click", hangUpCall);
