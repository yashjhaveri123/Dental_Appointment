Dental Appointment Booking System
Welcome to the Dental Appointment Booking System! This project is a web-based solution designed to make scheduling dental appointments as easy as possible. With a voice-enabled assistant and an intuitive user interface, it's designed to simplify the process for both patients and clinics.

Features
What It Does
Voice Bot Integration: Chat with a voice assistant to book your dental appointments.
Chat Logs: See a record of all interactions with the assistant.
Booking Logs: View details of all confirmed appointments, including the date, time, procedure, and patient name.
Manual Call Controls: Easily start or stop the voice bot whenever you need.
Noteworthy Additions
Real-time Booking Updates: The system captures and logs appointment details during conversations.
Responsive Design: Works seamlessly across devices, whether you're on a computer or a phone.
User-friendly Interface: Simple and clean design for easy navigation.
Note: The live transcript and real-time bookings update code is included in the project but is currently not functional.

Getting Started
What You Need
Make sure you have:
A modern web browser (e.g., Chrome, Firefox, Edge)
A development server like Vite or a similar tool to run the app locally
Steps to Launch
Clone the Repository

 git clone https://github.com/yashjhaveri123/Dental_Appointment.git


Open the Project

 cd dental-appointment-booking


Run It Use Vite to run the project locally:

 vite



How to Use
Activate the Voice Assistant


Click the "Activate Voice Bot" button to start chatting.
Provide appointment details like your name, preferred date, time, and procedure.
Check Logs


Conversations with the assistant will show up in the Chat Logs section.
Confirmed bookings will appear in the Booking Logs section.
End the Session


Click the "Hang Up" button to stop the voice bot. Any captured booking details will still be saved.

Project Structure
my-project/
|
|-- index.html       # Main file for the web interface
|-- main.js          # JavaScript for voice bot and UI logic
|-- styles.css       # CSS styles (embedded in index.html)


Known Issues
The live transcript and real-time bookings update features are not fully operational at the moment.

For any questions or suggestions, feel free to reach out.


